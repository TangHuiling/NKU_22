import cv2
import numpy as np
from flask import Flask, render_template, request
from Util import draw_allround_faces_on_image

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index1.html")


@app.route("/pic_recognition.html", methods=["POST", "GET"])
def next1():
    return render_template("pic_recognition.html")


@app.route("/pic_recognition.html/after", methods=["POST", "GET"])
def after():
    img = request.files['file1']
    img.save('static/file.jpg')
    ###############
    img1 = cv2.imread('static/file.jpg')
    img_final, emo_freq = draw_allround_faces_on_image(img1)
    cv2.imwrite('static/img_final.jpg', img_final)
    return render_template("after.html", data=emo_freq)


if __name__ == "__main__":
    app.run(debug=True)
